Switch Matrix addon board 
Using molex KK connectors for ease connecting all matrix switches
Designed with same design as CobraPin boards
